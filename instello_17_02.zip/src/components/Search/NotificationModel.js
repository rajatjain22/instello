import Image from "next/image";
import Link from "next/link";
import { IoCheckmarkCircleOutline, IoSettingsOutline } from "react-icons/io5";

export default function NotificationModel() {
  return (
    <>
      <div class='flex items-center justify-between px-5 py-4 mt-3'>
        <h3 class='md:text-xl text-lg font-medium mt-3 text-black dark:text-white'>
          Notification
        </h3>

        <div class='flex items-center gap-2 text-xl'>
          <IoSettingsOutline />
          <IoCheckmarkCircleOutline />
        </div>
      </div>

      <div class='px-2 -mt-2 text-sm font-normal'>
        <div class='px-5 py-3 -mx-2'>
          <h4 class='font-semibold'>New</h4>
        </div>

        <Link
          href='#'
          class='relative flex items-center gap-3 p-2 duration-200 rounded-xl hover:bg-secondery'
        >
          <div className='relative w-12 h-12 shrink-0'>
            <Image
              className='object-cover w-full h-full rounded-full'
              src={`/people-know/avatar-1.jpg`}
              alt='Picture of the author'
              fill={true}
              loading='lazy'
            />
          </div>

          <div class='flex-1 '>
            <p>
              <b class='font-bold mr-1'> John Michael</b> who you might know, is
              on Instello.
            </p>
            <div class='text-xs text-gray-500 mt-1.5 dark:text-white/80'>
              2 hours ago
            </div>
          </div>
          <button type='button' class='button text-white bg-primary'>
            fallow
          </button>
        </Link>

        <div class='border-t px-5 py-3 -mx-2 mt-4 dark:border-slate-700/40'>
          <h4 class='font-semibold'>This Week</h4>
        </div>

        <Link
          href='#'
          class='relative flex items-center gap-3 p-2 duration-200 rounded-xl hover:bg-secondery'
        >
          <div className='relative w-12 h-12 shrink-0'>
            <Image
              className='object-cover w-full h-full rounded-full'
              src={`/people-know/avatar-1.jpg`}
              alt='Picture of the author'
              fill={true}
              loading='lazy'
            />
          </div>
          <div class='flex-1 '>
            <p>
              <b class='font-bold mr-1'> Jesse Steeve</b> sarah tagged you
              <br /> in a photo of your birthday party. 📸
            </p>
            <div class='text-xs text-gray-500 mt-1.5 dark:text-white/80'>
              8 hours ago
            </div>
          </div>
        </Link>
      </div>
    </>
  );
}

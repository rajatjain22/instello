"use client";

import React, { useEffect, useState } from "react";
import SideNav from "../SideNavBar/SideNavBar";
import NavModel from "../Search/NavModel";
import SearchModel from "../Search/SearchModel";
import NotificationModel from "../Search/NotificationModel";
import { usePathname } from "next/navigation";
import CreatePost from "../PostContainer/CreatePost";
import CreatePostNew from "../PostContainer/CreatePostNew";
import AddPost from "../PostContainer/AddPost";

export default function MainComponent({ children }) {
  const pathname = usePathname();
  const isPublicPath = pathname === "/login" || pathname === "/register";

  const [toggle, setToggle] = useState({
    search: false,
    notifications: false,
  });

  const handleToggle = (key) => {
    setToggle((prevToggle) => ({
      ...prevToggle,
      [key]: !prevToggle[key],
      [key === "search" ? "notifications" : "search"]: false,
    }));
  };

  return (
    <>
      <main className="flex min-h-screen">
        {!isPublicPath ? <SideNav handleToggle={handleToggle} /> : ""}
        <div className="w-full bg-body-color h-screen overflow-y-scroll relative">
          <div className="main__inner">{children}</div>
          {toggle.search && (
            <NavModel>
              <SearchModel setToggle={setToggle}/>
            </NavModel>
          )}
          {toggle.notifications && (
            <NavModel>
              <NotificationModel />
            </NavModel>
          )}
        </div>
      </main>
    </>
  );
}

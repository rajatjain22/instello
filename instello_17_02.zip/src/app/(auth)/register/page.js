import Register from "@/components/Register/Register";

export default function page() {
  return <Register />;
}

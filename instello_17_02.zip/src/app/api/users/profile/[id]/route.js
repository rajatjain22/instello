import dbConnect from "@/dbconfig/dbconfig";
import verifyJWT from "@/jwt/verifyJWT";
import Users from "@/schemas/UserModel";
import { NextResponse } from "next/server";

await dbConnect();

export async function GET(request, { params }) {
  try {
    const query = params.id;
    const token = request.cookies.get("token")?.value || "";

    let userId;
    if (query == "user") {
      const data = verifyJWT(token);
      userId = data?.id;
    } else {
      userId = query;
    }
    
    const user = await Users.findOne({ _id: userId })
    .select("-password -createdAt -updatedAt -__v -lastLoginAt")
    .populate([
      { path: "posts" },
      { path: "followers" },
      { path: "following" },
    ]);
    
    return NextResponse.json({
      message: "User Found",
      data: user,
    });
  } catch (error) {
    console.log(error);
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}

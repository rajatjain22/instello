import Login from "@/components/Login/Login";

export default function page() {
  return (
    <Login />
  )
}

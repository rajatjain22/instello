export default function NavModel({ children }) {
  return (
    <div className='fixed top-0 sm:w-[397px] w-full sm:h-screen bg-white shadow-lg dark:bg-dark2 dark:border1 max-md:bottom-[57px]'>
      {children}
    </div>
  );
}
